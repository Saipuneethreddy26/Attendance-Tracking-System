Project Name: Visvas Attendence Form

You can visit https://github.com/nithin521/RegisterForm2 to download all files 

In the views folder we have ejs file (The html of the project and inline js)

In the stylesheet folder there is a file called style.css for styling

In the databse.js we connected our server with the our database 

In app.js all the code is uploaded for each route and the controllers are seperated in a seperate folder called controllers for every get or post request.

The database of this project is uploaded in the sql file 

Requirements:

To run this project u need to download node js from https://nodejs.org/en/download

U should have VSCode.

To run code:

After downloading files from github u need to npm i to install all the packages that are required in this project or u can do manually by downloading 1 by 1 from package.json
